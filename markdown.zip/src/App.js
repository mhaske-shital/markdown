
import Home from './componets/Home';

function App() {
  return (
    <>
      <Home />
    </>
  );
}

export default App;
